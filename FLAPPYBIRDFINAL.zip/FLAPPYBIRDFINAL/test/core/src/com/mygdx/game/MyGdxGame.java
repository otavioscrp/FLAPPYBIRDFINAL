package com.mygdx.game;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Preferences;
import com.badlogic.gdx.audio.Sound;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Circle;
import com.badlogic.gdx.math.Intersector;
import com.badlogic.gdx.math.Rectangle;

import java.util.Random;

public class MyGdxGame extends ApplicationAdapter {

	//Variaveis de pontuação, gravidade e etc
	private int pontuacaoMaxima = 0;
	private int pontos = 0;
	private int gravidade = 0;
	private int estadojogo = 0;

	//Determinar texturas que serão armazenadas
	private Texture[] passaros;
	private Texture fundo;
	private Texture canoAlto;
	private Texture canoBaixo;
	private Texture GameOver;

	//Respectivamente, dimensões dadas pelo dispositivo, variação de animações,
	//posicionamento dos canos e do pássaro e espaçamento.
	private float variacao = 0;
	private float larguradispositivo;
	private float alturadispositivo;
	private float posicaoInicialVerticalPassaro;
	private float posicaoCanoHorizontal;
	private float posicaoCanoVertical;
	private float espacoEntreCanos;
	private float posicaoHorizontalPassaro = 0;

	private SpriteBatch batch;

	// "Canvas"/Interface de reinicio e pontuação
	BitmapFont textPontuacao;
	BitmapFont textReniciar;
	BitmapFont textMelhorPontuacao;

	//Sons do sistema
	Sound somVoando;
	Sound somColisao;
	Sound somPontuacao;

	private boolean passouCano = false;

	private Random random;



	private ShapeRenderer shapeRenderer;
	//variação de colisão por formas geometricas primitivas
	private Circle circuloPassaro;
	private Rectangle retaguloCanoCima;
	private Rectangle retanguloBaixo;

	Preferences preferencias;


	@Override
	public void create() {

		//Começar o jogo com os metodos de carregamento/renderização de objetos e texturas
		inicializarObjetos();
		inicializaTexuras();

	}

	@Override
	public void render() {

		//Respectivamente, métodos de verificação de estado, detecção de colisão e texturas, e contagem de pontos
		verificaEstadojogo();
		desenharTexturas();
		detectarColisao();
		validarPontos();
	}

	private void inicializarObjetos() {

		random = new Random();
		batch = new SpriteBatch();

		//determinar as dimensões usadas no dispositivo
		larguradispositivo = Gdx.graphics.getWidth();
		alturadispositivo = Gdx.graphics.getHeight();

		//posicionamento do passaro na metade da altura do dispositivo e no começo do eixo de largura
		posicaoInicialVerticalPassaro = alturadispositivo / 2;
		posicaoCanoHorizontal = larguradispositivo;

		espacoEntreCanos = 350;

		//configuração de texto na interface do jogo(cor, tamanho, etc)
		textPontuacao = new BitmapFont();
		textPontuacao.setColor(com.badlogic.gdx.graphics.Color.WHITE);
		textPontuacao.getData().setScale(10);

		textReniciar = new BitmapFont();
		textReniciar.setColor(Color.RED);
		textReniciar.getData().setScale(2);

		textMelhorPontuacao = new BitmapFont();
		textMelhorPontuacao.setColor(Color.GREEN);
		textMelhorPontuacao.getData().setScale(3);


		//determinação de colisões
		shapeRenderer = new ShapeRenderer();
		circuloPassaro = new Circle();
		retaguloCanoCima = new Rectangle();
		retanguloBaixo = new Rectangle();


		//selecionando assets para o sistema de som
		somVoando = Gdx.audio.newSound(Gdx.files.internal("som_asa.wav"));
		somColisao = Gdx.audio.newSound(Gdx.files.internal("som_batida.wav"));
		somPontuacao = Gdx.audio.newSound(Gdx.files.internal("som_pontos.wav"));

		preferencias = Gdx.app.getPreferences("flappybird");
		pontuacaoMaxima = preferencias.getInteger("pontuacaoMaxima", 0);

	}

	private void inicializaTexuras() {

		//selecionando assets para configurar as texturas
		fundo = new Texture("fundo.png");

		//criação de um array para as animações do pássaro
		passaros = new Texture[3];
		passaros[0] = new Texture("passaro1.png");
		passaros[1] = new Texture("passaro2.png");
		passaros[2] = new Texture("passaro3.png");

		//selecionando assets para os canos
		canoAlto = new Texture("cano_topo_maior.png");
		canoBaixo = new Texture("cano_baixo_maior.png");
		GameOver = new Texture("game_over.png");


	}


	private void detectarColisao() {

		//setando configurações de colisão do pássaro e dos canos de cima e de baixo
		circuloPassaro.set(50 + passaros[0].getWidth() / 2,
				posicaoInicialVerticalPassaro + passaros[0].getHeight() / 2, passaros[0].getWidth() / 2);

		retanguloBaixo.set(posicaoCanoHorizontal,
				alturadispositivo / 2 - canoBaixo.getHeight() - espacoEntreCanos / 2 + posicaoCanoVertical,
				canoBaixo.getWidth(), canoBaixo.getHeight());

		retaguloCanoCima.set(posicaoCanoHorizontal,
				alturadispositivo / 2 + espacoEntreCanos / 2 + posicaoCanoVertical, canoAlto.getWidth(),
				canoAlto.getHeight());// pondo colisão nos canos

		//verificar colisão
		boolean bateuCanoCima = Intersector.overlaps(circuloPassaro, retaguloCanoCima);
		boolean bateuCanoBaixo = Intersector.overlaps(circuloPassaro, retanguloBaixo);

		//se colidiu, aparecer mensagem no Log mostrando colisão
		if (bateuCanoBaixo || bateuCanoCima) {
			Gdx.app.log("Log", "Colidiu");

			if (estadojogo == 1) {
				somColisao.play();
				estadojogo = 2;
			}
		}
	}

	private void validarPontos() {
		//distribuição da pontuação ao passar os canos
		if (posicaoCanoHorizontal < 50 - passaros[0].getWidth()){
			if (!passouCano){
				pontos++;
				passouCano = true;
				somPontuacao.play();
			}

		}

		variacao += Gdx.graphics.getDeltaTime() * 10;
		if (variacao > 3)
			variacao = 0;
	}

	private void verificaEstadojogo() {

		//verificação de toque de tela do jogador
		boolean toqueTela = Gdx.input.justTouched();

		//ação de pulo do pássaro
		if (estadojogo == 0) {
			if (Gdx.input.justTouched()) {
				gravidade = -15;
				estadojogo = 1;
				somVoando.play();
			}

		} else if (estadojogo == 1) {

			if (Gdx.input.justTouched()) {
				gravidade = -15;
				somVoando.play();
			}

			//posicionamento e movimentação dos canos
			posicaoCanoHorizontal -= Gdx.graphics.getDeltaTime() * 200;
			if (posicaoCanoHorizontal < -canoBaixo.getHeight()) {
				posicaoCanoHorizontal = larguradispositivo;
				posicaoCanoVertical = random.nextInt(400) - 200;
				passouCano = false;
			}


			if (posicaoInicialVerticalPassaro > 0 || toqueTela)
				posicaoInicialVerticalPassaro = posicaoInicialVerticalPassaro - gravidade;


			//aumento constante de gravidade
			gravidade++;

			//ação determinada ao colidir com o cano, ou seja, determinada a pontuação do jogador
		} else if (estadojogo == 2) {
			if (pontos > pontuacaoMaxima) {
				pontuacaoMaxima = pontos;
				preferencias.putInteger("pontuacaoMaxima", pontuacaoMaxima);
			}

			posicaoHorizontalPassaro -= Gdx.graphics.getDeltaTime() * 500;


			//resetar dados do jogo ao reiniciar
			if (toqueTela) {
				estadojogo = 0;
				pontos = 0;
				gravidade = 0;
				posicaoHorizontalPassaro = 0;
				posicaoInicialVerticalPassaro = alturadispositivo / 2;
				posicaoCanoHorizontal = larguradispositivo;
			}


		}
	}

	private void desenharTexturas() {

		batch.begin();

		batch.draw(fundo, 0, 0, larguradispositivo, alturadispositivo);
		batch.draw(passaros[(int) variacao], 50 + posicaoHorizontalPassaro, posicaoInicialVerticalPassaro);
		batch.draw(canoBaixo, posicaoCanoHorizontal,
				alturadispositivo / 2 - canoBaixo.getHeight() - espacoEntreCanos / 2 + posicaoCanoVertical);
		batch.draw(canoAlto, posicaoCanoHorizontal, alturadispositivo / 2 + espacoEntreCanos / 2 + posicaoCanoVertical);
		textPontuacao.draw(batch, String.valueOf(pontos), larguradispositivo / 2, alturadispositivo - 100);

		//interface principal do jogo
		if (estadojogo == 2) {
			batch.draw(GameOver, larguradispositivo / 2 - GameOver.getWidth() / 2, alturadispositivo / 2);
			textReniciar.draw(batch, "Toque  na tela para reiniciar!",
					larguradispositivo / 2 - 200, alturadispositivo / 2 - GameOver.getHeight() / 2);
			textMelhorPontuacao.draw(batch, "Sua melhor pontuação  é : " + pontuacaoMaxima + " Pontos",
					larguradispositivo / 2 - 300, alturadispositivo / 2 - GameOver.getHeight() * 2);
		}

		batch.end();
	}

	@Override
	//Principal método primario do projeto (Não foi necessário o uso dele para este projeto em específico)
	public void dispose() {

	}


}